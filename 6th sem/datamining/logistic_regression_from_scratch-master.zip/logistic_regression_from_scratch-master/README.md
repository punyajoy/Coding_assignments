# logistic_regression_from_scratch
Logistic Regression from scratch in Python

Jupyter Notebook to accompany the Logistic Regression from scratch in Python blog post.
